/*------------------------------------------------------------------------------*
 * File Name: GetNDlg.h															*
 * Creation: CPY 1/15/2004														*
 * Purpose: Origin C for GetNBox's TreeEditControl to be used in any dialog		*
 * Copyright (c) OriginLab Corp.2004											*
 * All Rights Reserved															*
 * 																				*
 * Modification Log:															*
 *------------------------------------------------------------------------------*/

#ifndef _GETN_DLG_H
#define _GETN_DLG_H

// support only one TreeEditControl 
class GetNBoxDlgBase : public ResizeDialog
{
public:
	GetNBoxDlgBase(UINT nDlgID, LPCSTR lpcszDLL) : ResizeDialog( nDlgID, lpcszDLL )
	{
	}
protected:
///////////////////////////////////////////
	BOOL OnSetFocus(Control cntrl)
	{
		return m_treeEditCntrl.OnSetFocus();
	}
	void OnBeforeEdit(Control cntrl, long nRow, long nCol, BOOL* pCancel)
	{		
		m_treeEditCntrl.OnBeforeEdit(nRow, nCol, pCancel);
	}
	void OnValidateEdit(Control cntrl, int nRow, int nCol, BOOL* pCancel)
	{
		m_treeEditCntrl.OnValidateEdit(nRow, nCol, pCancel);
	}
	void OnAfterEdit(Control flxControl, int nRow, int nCol)
	{
		m_treeEditCntrl.OnAfterEdit(nRow, nCol);
	}
	void OnButtonClick(Control cntrl, int nRow, int nCol)
	{
		m_treeEditCntrl.OnButtonClick(nRow, nCol);
	}
	void OnRowColChange(Control cntrl)
	{
		m_treeEditCntrl.OnRowColChange();
	}	
	void OnDrawCell(Control cntrl, UINT hDC, int nRow, int nCol, int nLeft, int nTop, int nRight, int nBottom, BOOL* pDone)
	{
		m_treeEditCntrl.OnDrawCell(hDC, nRow, nCol, nLeft, nTop, nRight, nBottom, pDone);
	}
	void OnComboCloseUp(Control cntrl, int nRow, int nCol, BOOL* pFinishEdit)
	{
		m_treeEditCntrl.OnComboCloseUp(nRow, nCol, pFinishEdit);
	}
	void OnBeforeMouseDown(Control cntrl, short nButton, short nShift, float X, float Y, BOOL* pCancel)
	{
		m_treeEditCntrl.OnBeforeMouseDown(nButton, nShift, X, Y, pCancel);
	}
	BOOL OnEditorKillFocus(uint wParam, uint lParam)
	{
		return m_treeEditCntrl.OnEditorKillFocus(wParam, lParam);
	}
	BOOL OnReconstructGrid(uint wParam, uint lParam)
	{
		if(m_treeEditCntrl.OnReconstructGrid(wParam, lParam))
			ResizeDlgToFit();

		return TRUE;
	}
///////////////////////////////////////////
	virtual BOOL OnDestroy(void)
	{
		m_treeEditCntrl.OnDestroy();
		return true;
	}

	virtual void ResizeDlgToFit() {}
	
protected:
	Tree				m_paramTree;
	TreeEditControl		m_treeEditCntrl;
};

// must add this to your dialog class's message map, 
#define ON_GETNDLG_MSGS(_ID) \
	ON_GRID_BEFORE_EDIT(_ID, OnBeforeEdit)	\
	ON_GRID_VALIDATE_EDIT(_ID, OnValidateEdit)	\
	ON_GRID_AFTER_EDIT(_ID, OnAfterEdit)	\
	ON_GRID_ROW_COL_CHANGE(_ID, OnRowColChange)	\
	ON_GRID_COMBO_CLOSEUP(_ID, OnComboCloseUp)	\
	ON_GRID_BEFORE_MOUSE_DOWN(_ID, OnBeforeMouseDown)	\
	ON_GRID_BUTTON_CLICK(_ID, OnButtonClick) \
	ON_GRID_DRAW_CELL(_ID, OnDrawCell) \
	ON_EVENT(EN_SETFOCUS, _ID, OnSetFocus) \
	ON_USER_MSG(WM_USER_ON_CHILD_KILL_FOCUS, OnEditorKillFocus) \
	ON_USER_MSG(WM_USER_RECONSTRUCT, OnReconstructGrid)

#endif //_GETN_DLG_H
	
