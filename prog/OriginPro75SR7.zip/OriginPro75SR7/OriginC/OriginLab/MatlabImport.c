/*------------------------------------------------------------------------------*
 * File Name:MatlabImport	 													*
 * Creation:CPY 01/02/03														*
 * Purpose: OriginC Source C file for Dialog Buidler Matlab Import Dialog		*
 * Copyright (c) Originlab Corporation, 2002, 2003								*
 * All Rights Reserved															*
 * 																				*
 * Modification Log:															*
 * DVT	1/2/03 QA70-3606 v7.0467 MATLAB_IMPORT_DIALOG_USE_MATLAB_CLASS			*
 * Soapy 8/10/03 QA70-4977														*
 * DVT 8/14/03 MATLAB_SINGLE_INSTANCE_FOR_MENU_IMPORT							*
 * AW 09/23/03 QA70-5164 SHOULD_NOT_USE_SAME_INSTANCE_WHEN_CALLED_FROM_MAT_CONSOLE
 *------------------------------------------------------------------------------*/
 
#include <Origin.h>
#include "MatlabImportDlg.h"

////////////////////////////////////////////////////////////////////////////////////

/// AW 09/23/03 QA70-5164 SHOULD_NOT_USE_SAME_INSTANCE_WHEN_CALLED_FROM_MAT_CONSOLE
//static MatlabImportDlg myMatlabImportDlg;
/// END SHOULD_NOT_USE_SAME_INSTANCE_WHEN_CALLED_FROM_MAT_CONSOLE

BOOL	MatlabImport(LPCSTR lpcszMatlabWkspaceName = NULL, HWND hParent = NULL, BOOL bSingle = FALSE)
{
	/// AW 09/23/03 QA70-5164 SHOULD_NOT_USE_SAME_INSTANCE_WHEN_CALLED_FROM_MAT_CONSOLE
	//MatlabImportDlg myMatlabImportDlg(lpcszMatlabWkspaceName);
	MatlabImportDlg myMatlabImportDlg;
	/// END SHOULD_NOT_USE_SAME_INSTANCE_WHEN_CALLED_FROM_MAT_CONSOLE
	int nRet = myMatlabImportDlg.DoModalEx(hParent,lpcszMatlabWkspaceName, bSingle);

	return nRet >= 0? true:false;
}


void MatlabWorkspaceImport()
{
	string strFilename = GetOpenBox( "[Matlab (*.MAT)] *.MAT" );
	if(strFilename.GetLength() > 0 && strFilename.IsFile())
		MatlabImport(strFilename, GetWindow(), TRUE);	//open non-shared instance always for file import
}   