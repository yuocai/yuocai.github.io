/*------------------------------------------------------------------------------*
 * File Name: common.h															*
 * Creation: CPY 7/14/2001														*
 * Purpose: OriginC header with common typedef and macros, must be included		*
 * Copyright (c) OriginLab Corp.	2001										*
 * All Rights Reserved															*
 * 																				*
 * Modification Log:															*
 * EJP 02-25-2004 v7.5827 FEEDBACK_MACROS_FOR_LOCAL_DEBUGGING					*
 *------------------------------------------------------------------------------*/
#ifndef _OC_COMMON_H
#define _OC_COMMON_H

typedef unsigned int size_t;

typedef int BOOL;
typedef void* LPVOID;
typedef const void* LPCVOID;
typedef const char* LPCSTR;
#define LPCTSTR	LPCSTR
typedef char* LPSTR;
typedef short SHORT;

///---------------------------- TD 8-15-01 
//typedef unsigned int UINT;
//#define DWORD	UINT
//#define	USHORT	WORD
#define DWORD	uint
#define	USHORT	ushort
#define WORD	ushort
#define BYTE	byte
#define String  string
//#define Vector  vector
//#define Matrix	matrix
#define UINT	uint
#define Application		Project
///------------------------ end TD 8-15-01 
typedef int LONG;
typedef int long;

#define SEEK_CUR    1
#define SEEK_END    2
#define SEEK_SET    0


#define HWND		LPVOID
#define	HANDLE		LPVOID
#define HBITMAP 	LPVOID
#define HMETAFILE 	LPVOID
#define	HICON		LPVOID
#define HINSTANCE	LPVOID
#define HDIB		LPVOID
#define HGDIOBJ		LPVOID
#define HENHMETAFILE LPVOID
#define HMENU		LPVOID

#define WINAPI      __stdcall

#define TRUE 	1
#define FALSE 	0

//-----------------------------------------------------
// the following should be defined only for debug build
#define _DEBUG // this is usful during development
//
#ifdef _DEBUG
	#define	DEBUG_MSG(str)	str.WriteLine(WRITE_COMPILER_OUTPUT)
#else
	#define	DEBUG_MSG(str)	str.Write(WRITE_MESSAGE_BOX)
#endif
#define OUT(str)		str.WriteLine(WRITE_SCRIPT_WINDOW)


#ifdef _DEBUG
	#define ASSERT(_f)	do { if (!(_f) ) OCAssertLine(__FILE__, __LINE__, 1);  } while (0)
#else
	#define ASSERT(_f)	do { if (!(_f) ) OCAssertLine(__FILE__, __LINE__, 0);  } while (0)
#endif

#pragma dll(@OK)

/**#
*/
void	OCAssertLine(LPCSTR lpcszFile, int nLineNumber, BOOL bDbg);


#define ERR_MSG(str)	{string _junk(str); OUT(_junk);}
//------------------------------------------------------

/// EJP 02-25-2004 v7.5827 FEEDBACK_MACROS_FOR_LOCAL_DEBUGGING
// These macros are for allowing feed back that is independent from debug settings.
// Debug messages are shown when debug is turned on.  There are times when you want
// to add output messages similar to debug messages but do not want to turn debug on.
// In this case you should add feed back messages to your code and then define _FEEDBACK
// at the top of your C/CPP file.
#ifdef _FEEDBACK
	#pragma message("FEEDBACK macros defined")
	#define FEEDBACK_STR(str)		{string _str(str); _str.WriteLine(WRITE_COMPILER_OUTPUT);}
	#define FEEDBACK_INT(n)			{string _str; _str.Format("%d", n); _str.WriteLine(WRITE_COMPILER_OUTPUT);}
	#define FEEDBACK_DBL(d)			{string _str; _str.Format("%f", d); _str.WriteLine(WRITE_COMPILER_OUTPUT);}
	#define FEEDBACK_STRSTR(sz,str)	{string _str; _str.Format("%s = %s", sz, str); _str.WriteLine(WRITE_COMPILER_OUTPUT);}
	#define FEEDBACK_STRINT(sz,n)	{string _str; _str.Format("%s = %d", sz, n); _str.WriteLine(WRITE_COMPILER_OUTPUT);}
	#define FEEDBACK_STRDBL(sz,d)	{string _str; _str.Format("%s = %f", sz, d); _str.WriteLine(WRITE_COMPILER_OUTPUT);}
#else // !_FEEDBACK
	#pragma message("FEEDBACK macros not defined")
	#define FEEDBACK_STR(str)
	#define FEEDBACK_INT(n)
	#define FEEDBACK_DBL(d)
	#define FEEDBACK_STRSTR(sz,str)
	#define FEEDBACK_STRINT(sz,n)
	#define FEEDBACK_STRDBL(sz,d)
#endif // !_FEEDBACK
/// end FEEDBACK_MACROS_FOR_LOCAL_DEBUGGING

#define	_ONAN		(-1.23456789E-300)

#define WM_USER		0x0400

#endif //_OC_ORIGIN_H

