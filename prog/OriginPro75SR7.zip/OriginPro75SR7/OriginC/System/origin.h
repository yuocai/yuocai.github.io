/*------------------------------------------------------------------------------*
 * File Name: Origin.h															*
 * Creation: CPY 3/1/2001														*
 * Purpose: Origin C main header												*
 * Copyright (c) OriginLab Corp.	2001										*
 * All Rights Reserved															*
 * 																				*
 * Modification Log:															*
 * EJP 07-25-2003 v7.0633 QA70-4895 PAGE_UTILITY_FUNCTIONS						*
 * AW 10/27/03 v7.0733 QA70-5398 ADD_OC_BASIC_IO								*
 *------------------------------------------------------------------------------*/
#ifndef _ORIGIN_H
#define _ORIGIN_H

#ifdef _FILES_TO_BE_IN_SYSTEM_AT_ALL_TIMES
#include <internal.h>
#include <matrix.h>
#include <GetNBox.h>
#include <analysis_utils.h>
#include <theme_utils.h>
#include <OriginEvents.h>
#include <tree_utils.h>
#include <LT_wks.h>
#include <LT_math.h>
#include <LT_PE.h>
#include <page_utils.h>
#endif //_FILES_TO_BE_IN_SYSTEM_AT_ALL_TIMES


#include <stdio.h> // Most usful to include this, has printf and etc.

#include <wksheet.h> // worksheet matrixlayer and column classes
#include <data.h>	 // Dataset, vector, matrix etc.
#include <File.h>	// File and StdioFile classes for basic file access
#include <Page.h> //File containing declaration of the class Page
#include <utilities.h> // basic utilities, including Win32 Kernal functions through mswin.h

#include <time.h>	/// AW 10/27/03 v7.0733 QA70-5398 ADD_OC_BASIC_IO
#include <conio.h>	/// AW 10/27/03 v7.0733 QA70-5398 ADD_OC_BASIC_IO

#include <graph.h> // graph, plot and graphic objects

#include <complex.h>

#include <math.h> // all math function prototypes and constants
#include <stat.h>

#include <Folder.h>

#if _OC_VER >= 0x0800
	// cannot compile this yet, need to find better solution
	//#include <Operation.h>
#endif

#include <Project.h> // The Project and Application class 

#include <sys_utils.h> // basic routines implemeted through Origin C, see sys_utils.c

#if  _OC_VER >= 0x0750
	#include <analysis_utils.h>
	#include <matrix.h>
	#include <tree_utils.h> // XML based Tree and TreeNode objects	
	#include <selection.h> // general Origin objects selection management
	#include <OC_nag.h> // this contains all the NAG headers, since Origin7.5 has precompiled header, so best to include as much as possible into this file 
	#include <matrixData.h>
	#include <page_utils.h> /// EJP 07-25-2003 v7.0633 QA70-4895 PAGE_UTILITY_FUNCTIONS
#endif //#if  _OC_VER >= 0x0750

#endif //_ORIGIN_H

