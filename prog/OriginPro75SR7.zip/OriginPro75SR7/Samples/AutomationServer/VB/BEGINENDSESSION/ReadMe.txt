================================================================================
BeginEndSession Example using OriginPro COM interface
================================================================================
The two applications in this folder are intended to demonstrate Origin Pro's
ability to act as a COM server for multiple applications.

The two applications can optionally use Session Control which will lock out
other applications to prevent conflicts which could occur.

Each application sends 500 strings to Origin indicating the source (1st APP or
2nd APP) and the current string index (1 to 500).


--------------------------------------------------------------------------------
To Demonstrate Multiple Clients using Shared Access
--------------------------------------------------------------------------------
1)  Launch Origin and open the Script Window (under the Window menu)
2)  Launch FirstApp.exe
3)  Launch SecondApp.exe
4)  Click the "Start 1st App" button, then immediately click the "Start 2nd App"
    button.

What happens:
Each application sends information to Origin. If you review the data, you will
note that FirstApp began sending data, then both FirstApp and SecondApp sent
data. FirstApp completed sending its data first and SecondApp continued until
all its data was sent.

--------------------------------------------------------------------------------
To Demonstrate Multiple Clients using Session Control
--------------------------------------------------------------------------------
    ( .. continuing from the previous example .. )
5)  Select File : New in the Script Window menu to clear it
6)  Check the "Use Begin/EndSession" CheckBox in the FirstApp application
7)  Click the "Start 1st App" button, then immediately click the "Start 2nd App"
    button.

What happens:
FirstApp begins sending data. SecondApp opens a message box with "SecondApp's
connection to Origin interrupted. SecondApp will keep trying." You can click OK
to retry, but the application will not connect until FirstApp has completed
sending its data ended its session.

    ( .. continuing from the previous example .. )
8)  Select File : New in the Script Window menu to clear it
9)  Uncheck the "Use Begin/EndSession" CheckBox in the FirstApp application
9)  Check the "Use Begin/EndSession" CheckBox in the SecondApp application
10) Click the "Start 1st App" button, then immediately click the "Start 2nd App"
    button.

What happens:
FirstApp begins sending data. When SecondApp Begins a Session, FirstApp is
locked out (Sessions have priority) and SecondApp sends all its data. When
SecondApp finishes, FirstApp can continue.


--------------------------------------------------------------------------------
Programmer Notes
--------------------------------------------------------------------------------
The program design implications of Begin/End Session are as follows:

A.) When designing an application that does NOT use Begin/End Session, consider
that:
        1) The application may be using Origin simultaneously with another
           application. You should create your own resources within Origin.
           You should not change any Origin Global properties.
	2) The application could be interrupted by another application that
           requests Begin/End Session.