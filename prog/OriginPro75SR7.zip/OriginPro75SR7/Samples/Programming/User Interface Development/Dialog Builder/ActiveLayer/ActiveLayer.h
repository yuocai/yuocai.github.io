//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by C:\C\Vc32\OriginC\Samples\Dialogs\ActiveLayer\ResDLL\ActiveLayer.rc
//
#define IDD_ACTIVELAYER_DLG             101
#define IDC_ACTIVE_LAYER                1000
#define IDC_ACTIVE_LAYER_X1             1000
#define IDC_ACTIVE_PAGE                 1001
#define IDC_ACTIVE_LAYER_X2             1002
#define IDC_ACTIVE_CURVE                1003
#define IDC_ACTIVE_LAYER_Y1             1004
#define IDC_ACTIVE_LAYER_Y2             1005
#define IDC_ACTIVE_OBJECT               1006

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        102
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
