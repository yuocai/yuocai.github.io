//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by D:\Origin80\OriginC\Samples\Dialogs\ActiveXDLG\ResDLL\ActiveXDLG.rc
//
#define IDD_AXD_ACTIVEX_DLG             100
#define IDC_AXD_VSFLEXGRID              6000
#define IDC_AXD_COMPUTE_BTN             6001

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        101
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         6002
#define _APS_NEXT_SYMED_VALUE           21000
#endif
#endif
