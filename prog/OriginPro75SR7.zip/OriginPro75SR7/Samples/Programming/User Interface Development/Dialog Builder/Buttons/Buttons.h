//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by D:\Origin80\OriginC\Samples\Dialogs\Buttons\ResDLL\Buttons.rc
//
#define IDD_BTNS_BUTTONS_DLG            100
#define IDC_BTNS_CHECK_BOX1             6000
#define IDC_BTNS_CHECK_BOX2             6001
#define IDC_BTNS_CHECK_BOX3             6002
#define IDC_BTNS_PUSH_BUTTON            6003

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        101
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         6004
#define _APS_NEXT_SYMED_VALUE           21000
#endif
#endif
