/*------------------------------------------------------------------------------*
 * File Name:				 													*
 * Creation: 																	*
 * Purpose: OriginC Source C file												*
 * Copyright (c) Originlab Corp. 2003, 2004, 2005, 2006, 						*
 * All Rights Reserved															*
 * 																				*
 * Modification Log:															*
 *------------------------------------------------------------------------------*/
 
#include <Origin.h>
#include <Dialog.h> 


////////////////////////////////////////////////////////////////////////////////////
// Include your own header files here.
#include "TwoGraphDlg.h" //CTwoGraphsDlg Dialog class	

////////////////////////////////////////////////////////////////////////////////////
// Start your functions here.
bool TwoGraphs()
{	
	CTwoGraphsDlg GraphDlg;
	GraphDlg.DoModal( GetWindow() );
	return true;
}
