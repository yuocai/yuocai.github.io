//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by D:\OriginPro75SR1\Samples\Programming\User Interface Development\Dialog Builder\ListDataSets\ResDLL\ListDataSets.rc
//
#define IDD_LDS_DLG                     100
#define IDC_LDS_LIST1                   6000
#define IDC_LDS_STATIC                  6001

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        101
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         6002
#define _APS_NEXT_SYMED_VALUE           21000
#endif
#endif
