//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by D:\OriginPro75J\Samples\Programming\User Interface Development\Dialog Builder\Radios\ResDLL\Radio Buttons.rc
//
#define IDD_ST_SET_TICKS_DLG            100
#define IDC_ST_INCREMENT_RB             6000
#define IDC_ST_NO_MAJOR_RB              6001
#define IDC_ST_INCREMENT_EBX            6002
#define IDC_ST_NO_MAJOR_EBX             6003

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        101
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         6004
#define _APS_NEXT_SYMED_VALUE           21000
#endif
#endif
