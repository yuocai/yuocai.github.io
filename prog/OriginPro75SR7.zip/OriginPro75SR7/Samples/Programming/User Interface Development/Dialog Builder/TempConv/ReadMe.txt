March 19, 2004

This document explains how to make a Dialog Builder DLL using 
Open Watcom C/C++ v1.2.

Open Watcom C/C++ is not owned nor distributed by OriginLab Corp.
To find out more about Open Watcom C/C++ and to download a copy 
please visit http://www.openwatcom.org/

The following files should have come with this document:

    TempConv.wpj       Open Watcom project file.
    TempConv.tgt       Open Watcom target file.
    TempConvDlg.res    Open Watcom resource script file.

    dllmain.c          Open Watcom source file.  I could not figure
                       out how to tell Open Watcom to make a resource
                       DLL.  Because of this I was forced to have a 
                       source code file containing a single empty
                       exported function.

    TempConvDlg.ocw    Origin C workspace file.
    TempConvDlg.cpp    Origin C source file for handling the dialog.

    resource.h         Header file containing IDs for the dialog and
                       its controls.  This is used by Open Watcom
                       and Origin C.

    ReadMe.txt         This document.


The following steps will show you how to make the Temperature
Converter DLL and how to use the DLL with Origin.

Making the DLL:
- Obtain and install a copy of Open Watcom C/C++.
- Run the Open Watcom IDE.
- Do "File > Open Project..." and choose the TempConv.wpj file.
- Do "Actions > Make all" to compile and link the DLL.

Using the DLL with Origin:
- Run Origin.
- Do "View > Code Builder".
- Switch to the Code Builder Window.
- Do "File > Open Workspace..." and choose TempConvDlg.ocw.
- Do "Tools > Build" to compile and link the TempConvDlg.cpp file.
- Switch to Origin's Script Window.
- Type "DoTempConvDlg" and press Enter.
