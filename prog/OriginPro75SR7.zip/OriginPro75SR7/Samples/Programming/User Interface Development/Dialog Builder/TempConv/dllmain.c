#include <windows.h>

BOOL WINAPI DllMain(HANDLE hinstDLL, DWORD dwReason, LPVOID lpvReserved)
{
    return TRUE;
}

int FAR PASCAL __export emptyfunc()
{
    return 0;
}

