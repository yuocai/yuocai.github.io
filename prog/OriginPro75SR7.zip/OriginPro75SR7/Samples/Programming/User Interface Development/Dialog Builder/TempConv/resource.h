#define IDD_TEMPCONV     100
#define IDC_CELSIUS      6000
#define IDC_FAHRENHEIT   6001
#define IDC_C_TO_F       6002
#define IDC_F_TO_C       6003
