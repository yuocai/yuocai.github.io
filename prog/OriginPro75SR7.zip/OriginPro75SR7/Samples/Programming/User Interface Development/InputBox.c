/*------------------------------------------------------------------------------*
 * File Name: InputBox.c														*
 * Creation: GJL, 7/14/2003														*
 * Purpose: OriginC Source C file for an input box example.						*
 * Copyright (c) OriginLab Corp.			2003, 2004, 2005, 2006, 2007		*
 * All Rights Reserved															*
 *------------------------------------------------------------------------------*/
 
#include <origin.h>

void InputBoxEx()
{
	string strInput;

	try
	{
		strInput = InputBox("Please enter your name:");
	}
	catch(int nErr)
	{
		printf("You clicked Cancel.\n");
		return;
	}

	printf("You entered: %s\n", strInput);
}