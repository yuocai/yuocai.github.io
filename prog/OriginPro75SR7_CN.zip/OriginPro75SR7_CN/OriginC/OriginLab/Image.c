/*------------------------------------------------------------------------------*
 * File Name:				 													*
 * Creation: 																	*
 * Purpose: OriginC Source C file												*
 * Copyright (c) ABCD Corp.	2000, 2001, 2002, 2003, 2004, 2005, 2006, 2007		*
 * All Rights Reserved															*
 * 																				*
 * Modification Log:															*
 *------------------------------------------------------------------------------*/
 
////////////////////////////////////////////////////////////////////////////////////
// you can include just this typical header file for most Origin built-in functions and classes
// and it takes a reasonable amount of time to compile, 
#include <origin.h>
#include <Tree.h>
#include "Filter_Utils.h"
// this file include most of the other header files except the NAG header, which takes longer to compile
// NAG routines
//#include <OC_nag.h> // this contains all the NAG headers, 

////////////////////////////////////////////////////////////////////////////////////


////////////////////////////////////////////////////////////////////////////////////
// start your functions here

int ImportImage(Page &pgTarget, TreeNode &trFilter, LPCSTR lpcszFile, int nFile)
{
	if( EXIST_MATRIX != pgTarget.GetType() )
		return 1; // target page is required
	if( !trFilter || trFilter.Type.nVal != FILTER_TYPE_USERDEFINED )
		return 1; // user defined filter is required
	if( !lpcszFile )
		return 1; // source file name is required
	
	using Image = LabTalk.Image;
	
	Image.FileName$ = lpcszFile;
	
	string strPageName = pgTarget.GetName();
	if( Image.Import.Matrix(strPageName) )
		return 1; // import error
	pgTarget.LT_execute("matrix -ii"); // show matrix as image
	
	return 0;
}

#if _OC_VER >= 0x0800
int ImportMultipleImages(string strMatrix)
{
	Page pg(strMatrix);
	if( pg )
		return ImportMultipleImages(pg);
	return 1; // error, 
}

int ImportMultipleImages(Page &pgTarget)
{
	StringArray saFiles;
	if( GetMultiOpenBox(saFiles, FDLOG_IMAGE) )
	{
		using Image = LabTalk.Image;

		Tree trFiles;
		string str, strPage = pgTarget.GetName();

		for( int iFile = 0; iFile < saFiles.GetSize(); iFile++ )
		{
			Image.FileName$ = saFiles[iFile];

			str.Format("File%d", iFile + 1);
			Image.Import.Object(strPage, str, 1); // 1=replace
			
			AppendImageFileNode(trFiles, str, saFiles[iFile]);

			str += ".show=0";
			pgTarget.LT_execute(str); // hide GrObject
		}
		
		///out_tree(trFiles); // for debugging
		vector<byte> vb;
		if( trFiles.XML.GetBytes(vb) )
			pgTarget.SetMemory("ImportFileInfo", vb);
	}
	return 0;
}

static BOOL AppendImageFileNode(Tree& tr, LPCSTR lpcstrNode, LPCSTR lpcstrFile)
{
	if( !tr || !lpcstrNode || !lpcstrFile )
		return FALSE; // all arguments required

	TreeNode trnFile = tr.AddNode(lpcstrNode);
	if( !trnFile )
		return FALSE;

	trnFile.AddTextNode(GetFileName(lpcstrFile), "FileName");
	trnFile.AddTextNode(lpcstrFile, "FilePath");
	
	// file date
	double dJulianDate = 0.0;
	WIN32_FILE_ATTRIBUTE_DATA fad;
	if( GetFileAttributesEx(lpcstrFile, 0, &fad) )
	{
		SYSTEMTIME st;
		if( FileTimeToSystemTime(&fad.ftLastWriteTime, &st) )
			SystemTimeToJulianDate(&dJulianDate, &st);
	}
	trnFile.AddNumericNode(dJulianDate, "FileDate");

	using Image = LabTalk.Image;
	string strFile = lpcstrFile;
	Image.FileInfo(strFile);
	trnFile.AddNumericNode(Image.FileInfo.Height, "Height");
	trnFile.AddNumericNode(Image.FileInfo.Width, "Width");
	trnFile.AddNumericNode(Image.FileInfo.BitsPerPixel, "BitsPerPixel");
	
	return TRUE;
}
#endif //_OC_VER >= 0x0800

