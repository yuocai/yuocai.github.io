/*------------------------------------------------------------------------------*
 * File Name: OSelFilter.h														*
 * Purpose: Handle the selection of a import filter								*
 * Copyright (c) Originlab Corp. 2003											*
 * All Rights Reserved															*
 * 																				*
 * Modification Log:															*
 *------------------------------------------------------------------------------*/

#ifndef _OSELFILTER_H
#define _OSELFILTER_H


bool SelectFilter(string &strFilterFile, LPCSTR lpcszDataFile);
typedef bool (*PFNSELECTFILTER)(string &strFilterFile, LPCSTR lpcszDataFile);
#define GET_SELECTFILTER_FUNC Project.FindFunction("SelectFilter", "OriginLab\\OSelFilter.c", TRUE)


#endif // _OSELFILTER_H
