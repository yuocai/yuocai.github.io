/*------------------------------------------------------------------------------*
 * File Name:PageListControl, Project Explorer Control							*
 * Creation: CPY Feb 29 2004													*
 * Purpose: A Control base class for showing a list of pages 					*
 * Copyright (c) Originlab Corp., 2004, 2005, 2006, 2007, 2008, 2009, 2010		*
 * All Rights Reserved															*
 * 																				*
 * Modification Log:															*
 *------------------------------------------------------------------------------*/
#ifndef _PAGE_CONTTROL_H
#define _PAGE_CONTTROL_H

enum {PEPAGE_LONGNAME, PEPAGE_SHORTNAME, PAGEG_SHEET_NAME, PEPAGE_N_COLS, PEPAGE_N_ROWS, PEPAGE_FILEPATH, PEPAGE_FILENAME, PEPAGE_FILEDATE, PEPAGE_PATH, PEPAGE_CREATED, PEPAGE_MODIFIED, PEPAGE_TOTAL_COLS};

class PageListControl : public GridListControl
{
	PageListControl()
	{
		m_bShowWksLayers = false;
		// must match enum {PEPAGE_NAME, PEPAGE_LABEL,
		GetFormatStrAsArray("Long Name|Book|Sheet|Cols|Rows|File Path|File Name|File Date|Folder|Created|Modified", m_vsColHeadings, "PEPages");
	}
	
public:
	void Init(int nID, WndContainer& dlg, LPCSTR lpcszDlgName, bool bShowWksLayers = true)
	{
		m_bShowWksLayers = bShowWksLayers;
		m_strDlgName = lpcszDlgName;
		vector<byte> vbDefaultShowCols = {0,1,0,0,0,1,0,0,1,0,0};		
		GridListControl::Init(nID, dlg);
		/*
		if(m_bShowWksLayers)
		{
			m_flx.OutlineCol = 0;
			m_flx.OutlineBar = flexOutlineBarSimpleLeaf;
		}
		*/
		m_flx.Cols = PEPAGE_TOTAL_COLS;
		m_flx.FormatString = makeColHeadings();
		m_flx.SelectionMode = flexSelectionListBox;
		m_flx.AllowSelection = true;
		m_flx.ExplorerBar = flexExSortShow;
		m_flx.Ellipsis = flexEllipsisPath;// if str too long, show ... in the middle
		LoadHideCols(m_strDlgName, "PageListHideShowCols", &vbDefaultShowCols);
		/*
		if(m_bShowWksLayers)
			HideCol(PEPAGE_OUTLINE, false);
		else
			HideCol(PEPAGE_OUTLINE, true);
		*/
	}
	//virtual 
	string GetRuntimeClass()
	{
		return "PageListControl";
	}
	BOOL OnDestroy()
	{
		SaveHideCols();
		return TRUE;
	}
protected:
	void ResizeCols(int nMaxColSizeFactor = 0, int nExtraPixcels = 8)
	{
		GridListControl::ResizeCols(nMaxColSizeFactor, nExtraPixcels);
		//if(m_bShowWksLayers)
		//	m_flx.ColWidth(PEPAGE_OUTLINE) = PixelsToTwips(13);
		
	}
	void AddAllWksPages()
	{
		foreach(WorksheetPage wkspg in Project.WorksheetPages)
			//m_flx.AddItem(makeRow(wkspg));
			addWksPage(wkspg);
			
	}
	void AddProjectMatrixPages()
	{
		foreach(MatrixPage mpg in Project.MatrixPages)
			m_flx.AddItem(makeRow(mpg));
		
		return;
	}
	void AddPages(Folder fldr, int nPageType = 0)
	{
		foreach(PageBase page in fldr.Pages)
		{
			if(nPageType && page.GetType() != nPageType)
				continue;
			
			//m_flx.AddItem(makeRow(page));
			AddPage(page, page.GetType());
		}
	}
	bool AddPage(PageBase pg, int nPageType)
	{
		if(isWksPageType(nPageType))
			return addWksPage(pg);
		
		if(pg)
		{
			m_flx.AddItem(makeRow(pg));
			SetCellIcon(m_flx.Rows - 1, 0, getDisplayIdFromPageID(pg.GetType()), MODULE_ORIGIN);//TD 3-30-04
			return true;
		}
		return false;
	}
	bool GetSelItems(vector<string>& vsWksNames)
	{
		vector<uint> vnRows;
		vsWksNames.SetSize(0);
		string strPage, strSheet;
		if(GetSelRows(vnRows))
		{
			for(int ii = 0; ii < vnRows.GetSize(); ii++)
			{
				strPage = m_flx.Cell(flexcpText, vnRows[ii], PEPAGE_SHORTNAME);
				strSheet = m_flx.Cell(flexcpText, vnRows[ii], PAGEG_SHEET_NAME);
				vsWksNames.Add(make_book_sheet_name(strPage, strSheet));
			}
			return true;
		}
		return false;
	}
private:
	/// TD 3-30-04 QA70-6053 PICTURE_IN_OC
	int getDisplayIdFromPageID(int nPageId)
	{
		switch(nPageId)
		{
		case EXIST_GRAPH:
			return IDR_GRAPHTYPE_V8;
		case EXIST_WKS:
			return IDR_WORKSHEETTYPE_V8;
		case EXIST_NOTES:
			return IDR_NOTESTYPE;
		case EXIST_EXTERN_WKS:
			return IDR_EXCELTYPE;
		case EXIST_MATRIX:
			return IDR_MATRIXTYPE_V8;
		};
		return IDI_FOLDER_CLOSED;

	}
	/// end PICTURE_IN_OC

	bool addWksPage(WorksheetPage wpg)
	{
		if(!wpg)
			return false;

		int nLayers = numDataSheets(wpg);
		for(int ii = 0; ii < nLayers; ii++)
		{
			m_flx.AddItem(makeRow(wpg, ii));
			SetCellIcon(m_flx.Rows - 1, 0, getDisplayIdFromPageID(EXIST_WKS), MODULE_ORIGIN);//TD 3-30-04
		}
		return true;
	}
	string 	getPageSystemInfo(PageBase pg, int nType)
	{
		string str;
		PageSystemInfo	PgInfo;
		pg.GetPageSystemInfo(&PgInfo);
		switch(nType)
		{
		case PEPAGE_MODIFIED:
			str = get_date_str(PgInfo.dModified);
			break;
		case PEPAGE_CREATED:
			str = get_date_str(PgInfo.dCreated);
			break;			
		}
		return str;
	}
	// nLayer >= 0 if wks layer row
	string makeCol(PageBase pgbase, int nColType, int nLayer = -1)
	{
		Page pg = pgbase;

		string strTemp;
		switch(nColType)
		{
	//	case PEPAGE_OUTLINE:
	//		return strTemp;
		case PAGEG_SHEET_NAME:
			if(nLayer >= 0)
			{
				Datasheet wks = pg.Layers(nLayer);
				wks.GetName(strTemp);
			}
			break;
		case PEPAGE_SHORTNAME:
			return pg.GetName();
		case PEPAGE_LONGNAME: // long name, if label empty, use tagName
			return page_get_display_name(pg);
		case PEPAGE_PATH:
			if(nLayer < 0)
			{
				Folder fld = pg.GetFolder();
				if(fld)
					strTemp = fld.GetPath();
				return strTemp;
			}
			break;
		case PEPAGE_N_COLS:
			if(numDataSheets(pg))
			{
				Datasheet wks = pg.Layers(nLayer);
				if(wks)
					strTemp = wks.GetNumCols();
				return strTemp;
			}
			break;
		case PEPAGE_N_ROWS:
			if(numDataSheets(pg))
			{
				Datasheet wks = pg.Layers(nLayer);
				if(wks)
					strTemp = wks.GetNumRows();
				return strTemp;
			}
			break;
		case PEPAGE_MODIFIED:
		case PEPAGE_CREATED:
			if(nLayer < 0)
				return getPageSystemInfo(pg, nColType);
			break;
		default:
			break;
		}
		if(pg && nLayer < 0)
			return getPageImportInfo(pg, nColType);
		
		return strTemp;// return empty
	}
	string makeRow(PageBase wkspg, int nLayer = -1)
	{
		string	str;// = wkspg.GetName() + "\t" + wkspg.Label;
		int	nCols = m_vsColHeadings.GetSize();
		for(int ii = 0; ii < nCols; ii++)
		{
			str += makeCol(wkspg, ii, nLayer);
			if(ii < nCols -1)
				str += "\t";
		}
		return str;
	}
	string getPageImportInfo(Page wkspg, int nType)
	{
		string str;
		storage st;
		st = wkspg.GetStorage("System");
		if(st)
		{
			Tree trTemp;
			if(st.GetSection("Import", trTemp) && trTemp.FilePath.IsValid())
			{
				switch(nType)
				{
				case PEPAGE_FILEPATH:
					str = GetFilePath(trTemp.FilePath.strVal);
					break;
				case PEPAGE_FILENAME:
					str = trTemp.FileName.strVal;
					break;
				case PEPAGE_FILEDATE:
					if(trTemp.FileDate.IsValid()) // this was added later, so need to check, the other two added together
					{
						double dateVal = trTemp.FileDate.dVal;
						str = get_date_str(dateVal, LDF_SHORT);
					}
					break;
				}
			}
		}
		return str;
	}
	string makeColHeadings()
	{
		string str;
		int	nCols = m_vsColHeadings.GetSize();
		for(int ii = 0; ii < nCols; ii++)
		{
			str += m_vsColHeadings[ii];
			if(ii < nCols -1)
				str += "|";
		}
		return str;
	}
	bool isWksPageType(int nPageType)
	{
		if(EXIST_WKS == nPageType || EXIST_EXTERN_WKS == nPageType)
			return true;
		
		return false;
	}
	int numDataSheets(PageBase pgb)
	{
		if(!pgb)
			return 0;
		int nPageType = pgb.GetType();
		
		if(EXIST_MATRIX == nPageType)
			return 1;
		if(isWksPageType(nPageType))
		{
			WorksheetPage wpg = pgb;
			int nLayers = wpg.Layers.Count();
			//if(nLayers > 0)
			//	printf("wks %s has %d sheets\n", wpg.GetName(), nLayers);
			return nLayers;
		}
		return 0;
	}
		
private:
	vector<string>	m_vsColHeadings;
	string			m_strDlgName;
	bool			m_bShowWksLayers;
protected:
	int				m_nNameCol;
};

#endif //_PAGE_CONTTROL_H

