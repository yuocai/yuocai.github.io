/*------------------------------------------------------------------------------*
 *      File Name:      oEvents.h												*
 *      Purpose:		events ID's to shared between ok and OC					*
 *      Date:			07/14/2003												*
 *		Creator:		YuI														*
 *      Copyright OriginLab Corp. 2002, 2003, 2004								*
 *      Modification log                                                        *
 *	YuI 12/05/03 v7.5778 QA70-5613 OC_CMDTARGET_HANDLER_FOR_ORIGIN_OBJECTS		*
 *	YuI 1/20/04 v7.5806 QA70-5853 OGS_EVENTS_WITH_PROJECT_IN_COMMAND_LINE		*
 *	YuI 3/23/04 v7.5843 QA70-6141 MORE_OGS_EVENTS								*
 *	TD 5-28-04 QA70-5346 EDITING_DIALOGBUILDER_GRAPHS_IN_ORIGIN_WORKSPACE		*
 *------------------------------------------------------------------------------*/

#ifndef	_OEVENTS_H
#define	_OEVENTS_H
typedef enum	tagORIGINEVENTID
{
	OE_CREATE_NEW_GRAPH_PAGE_ADD_DATA,	// fires after create new graph page and add data
	OE_AFTER_LOAD_FROM_TEMPLATE,		// fires after loading from template
	OE_BEFORE_CNF,						// fires before execution of any CNF file
	OE_AFTER_CNF,						// fires after execution of all CNF files
	OE_BEFORE_COMPILE_SYSTEM,			// fires before startup compilation of system folder
	OE_AFTER_COMPILE_SYSTEM,			// fires after startup compilation of system folder
	OE_BEFORE_OPEN_DOC,					// fires before Origin project is loaded
	OE_AFTER_OPEN_DOC,					// fires after Origin project is loaded
	OE_BEFORE_CLOSE_DOC,				// fires before Origin project is closed
	OE_AFTER_CLOSE_DOC,					// fires after Origin project is closed
	OE_EXIT_ORIGIN,						// fires before exiting origin but after OE_AFTER_CLOSE_DOC\
	/// YuI 1/20/04 v7.5806 QA70-5853 OGS_EVENTS_WITH_PROJECT_IN_COMMAND_LINE
	OE_BEFORE_COMPILE_PROJECT,
	OE_AFTER_COMPILE_PROJECT,
	/// end OGS_EVENTS_WITH_PROJECT_IN_COMMAND_LINE
	/// YuI 3/23/04 v7.5843 QA70-6141 MORE_OGS_EVENTS
	OE_BEFORE_SAVE_DOC,
	OE_AFTER_SAVE_DOC,
	/// end MORE_OGS_EVENTS
	/// TD 5-25-04 QA70-6400 FIRE_OCEVENTS_FOR_WKS_CONTEXT_MENUS
	OE_ONCONTEXTMENU_WKSLAYER,
	OE_ONCONTEXTMENU_WKSPAGE,
	OE_ONCONTEXTMENU_SHEET_TAB,
	/// end FIRE_OCEVENTS_FOR_WKS_CONTEXT_MENUS
	/// TD 5-28-04 QA70-5346 EDITING_DIALOGBUILDER_GRAPHS_IN_ORIGIN_WORKSPACE
	OE_DBPAGE_BEFORE_ATTACH_MDI,
	OE_DBPAGE_AFTER_ATTACH_MDI,
	OE_DBPAGE_BEFORE_DETACH_MDI,
	OE_DBPAGE_AFTER_DETACH_MDI,
	/// end EDITING_DIALOGBUILDER_GRAPHS_IN_ORIGIN_WORKSPACE
}	ORIGINEVENTID;

/// YuI 12/05/03 v7.5778 QA70-5613 OC_CMDTARGET_HANDLER_FOR_ORIGIN_OBJECTS
// this set of events intended to be handled by command target of different objects
typedef enum	tagORIGINCMDTARGETEVENTID
{
	OE_NONE = -1,
	// generic events 
	OE_MOVE,
	OE_MOVING,
	OE_RESIZE,
	OE_RESIZING,
	OE_DELETE,
	OE_SELECT,
	OE_UNSELECT,
	OE_BUTTONCLICK,

	//graph object related 
	OE_GRAPHOBJ_ROTATE,
	OE_GRAPHOBJ_ROTATING,
	OE_GRAPHOBJ_SKEW,
	OE_GRAPHOBJ_SKEWING,
	OE_GRAPHOBJ_EDIT,
	OE_GRAPHOBJ_EDITING,
	// user events
}	ORIGINCMDTARGETEVENTID;
/// end OC_CMDTARGET_HANDLER_FOR_ORIGIN_OBJECTS

typedef	enum tagORIGINEVENTMESSAGE
{
	OE_MSG_FIRE,
	OE_MSG_SET_OGS_FILE_NAME,
}	ORIGINEVENTMESSAGE;
#endif //_OEVENTS_H