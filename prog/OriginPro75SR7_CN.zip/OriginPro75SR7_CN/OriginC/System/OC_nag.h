/*------------------------------------------------------------------------------*
 * File Name: OC_NAG.h															*
 * Creation: CPY 5/15/2001														*
 * Purpose: Origin C Header for NAG functions									*
 * Copyright (c) OriginLab Corp.	2001										*
 * All Rights Reserved															*
 * 																				*
 * Modification Log:															*
 *------------------------------------------------------------------------------*/

#ifndef _O_NAG_H
#define _O_NAG_H

//#importdll "ONAG" // NAG DLL prepared by OriginLab
#pragma dll(ONAG)

#include <NAG\nag_types.h>
#include <NAG\OCN_c06.h>
#include <NAG\OCN_e01.h>
#include <NAG\OCN_e02.h>
#include <NAG\OCN_f.h>
#include <NAG\OCN_f06.h>
#include <NAG\OCN_g01.h>
#include <NAG\OCN_g02.h>
#include <NAG\OCN_g03.h>
#include <NAG\OCN_g04.h>
#include <NAG\OCN_g08.h>
#include <NAG\OCN_g11.h>
#include <NAG\OCN_g12.h>
#include <NAG\OCN_s.h>

/** a00aaa
		Free memory allocated by NAG functions.
*/
void nag_free(void * pvoid); // Free memory allocated by NAG functions.

#endif //!_O_NAG_H