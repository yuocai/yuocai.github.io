/*------------------------------------------------------------------------------*
 * File Name: OrgObj.h															*
 * Creation: CPY 1/7/2002													    *
 * Purpose: OriginObject, this the base class for all Origin internal objects	*
 * Copyright (c) OriginLab Corp.2001, 2002										*
 * All Rights Reserved															*
 * 																				*
 * Modification Log:															*
 *------------------------------------------------------------------------------*/
#ifndef _ORGOBJ_H
#define _ORGOBJ_H

/** >Internal Origin Objects
		The OriginObject class is the base class for all internal Origin objects and
		provides the methods and properties common to all Origin objects.
	Example:
		// If a worksheet is the active window in Origin than wks will be valid
		Worksheet wks;
		wks = (Worksheet) Project.ActiveLayer();
		if(wks.IsValid())
			out_str("Worksheet is Valid!");
		else
			out_str("Worksheet is not Valid!");
*/
class OriginObject
{
public:
	OriginObject();

	/**
			Checks Validity of the Origin object.
		Return:
			FALSE if an Origin Object is not valid, non-zero otherwise.
		Example:
			void test(Worksheet& aa)
			{
				if(aa.IsValid())
					out_str("Worksheet is Valid!");
				else
					out_str("Worksheet not Valid!");
			}
	*/
	BOOL		IsValid();

	/**
	DestroyObject
	Remark: 
		If the Origin object is a layer and it is the only one in the window, then also destroy the window (page).
	Example:
        Worksheet wks = Project.ActiveLayer();
		ASSERT(wks.IsValid());
		wks.Destroy();
		ASSERT(!wks.IsValid());

	Return:
		TRUE for success
	*/
	BOOL		Destroy();

	/**
	Show or hide the Origin object
	Parameters: 
		bShow = optional argument (TRUE to show the object, FALSE - to hide)
	Return:
		TRUE for success, otherwise FALSE
	Example:
        Page page = Project.Pages();
		if (page)
		page.Show(FALSE);	// hide worksheet page
	*/
	BOOL		Show(BOOL bShow = TRUE);

	/**
	Retrieve parent of origin object. 
	Parameters:
		obj = reference to object to which parent will be attached.

	Example:
		Worksheet wks = Project.ActiveLayer();
		Column col(wks, 1);
		if (col)
		col.GetParent(wks); // wks is worksheet to which column belongs.
	*/	
	void		GetParent(OriginObject& obj);		

#ifdef _OPERATION_H
	/**
	*/	
	void		GetOperation(OperationBase& op);
#endif	//_OPERATION_H
	
#if _OC_VER >= 0x0800
	/**#
	*/
	BOOL	SetCmdTarget(LPCSTR lpcszClassName);
	
	/**#
	*/
	string	GetCmdTarget();
	/**#?
		Invalidate OriginObject
	*/
	void		Invalidate(BOOL bUpdate = TRUE);
	/**#?
		It gets the index of an obejct in a collection, for example, for a Column to return the index in the sheet
	Paramaters:
		None
	Returns:
		The object's index, zero offset.
	Example:
		Worksheet wks = Project.ActiveLayer();
		Column col(wks, 1);
		ASSERT(col.GetIndex() == 1);
		// wks also have layer index in book
		out_int("Current sheet index = ", wks.GetIndex());
		
	**/
	int 		GetIndex();
	/**#?
		It sets the index of an obejct in a collection
	Paramaters:
		None
	Returns:
		Return true if set the object's index success, false NO.
	Example:
		WorksheetPage wkPage;
		wkPage.Create();
	
		wkPage.AddLayer();
		wkPage.AddLayer();
		
		Worksheet wksLayer3 = wkPage.Layers(2);
		bool bRet = wksLayer3.SetIndex(0);
		ASSERT(bRet);
		int nIndex =  wksLayer3.GetIndex();
		ASSERT(nIndex == 0);
	*/
	BOOL		SetIndex(int nIndex, BOOL bUndo = TRUE);
	
	
	/**#?
		It retrieves the long name of an object that supports both long and short names
	Paramaters:
		None
	Returns:
		The long name if present, or empty string if long name not supported, or object does not support long name
	Remarks:
		Only Column and Page objects support long name
	Example:
		void test_GetLongName()
		{
				WorksheetPage wp;
				bool bRet = wp.Create();
				if(!bRet)
					return ;
				string strName = "Hello World";
				bRet = wp.SetLongName(strName);
				ASSERT(bRet);
				string strResult  = wp.GetLongName();
				ASSERT(0 == strResult.CompareNoCase(strName));
				printf("The worksheetPage longname is %s", strResult);
		}
	*/
	string		GetLongName();
	
	/**#?
		It sets the long name of an object that supports both long and short names
	Parameters:
		lpcszLongName=pointer to the long name to set
	Remarks:
		Only Column and Page objects support long name
	Returns:
		TRUE if OK. FALSE if object does not have long name support
	Example:
		Worksheet wks = Project.ActiveLayer();
		Column col(wks, 1);
		col.SetLongName("A test, col can have long name");
		string str = col.GetLongName();
		out_str(str);
		// wks does not support long name
		BOOL bb = wks.SetLongName("Some junk");
		ASSERT(bb==FALSE);
		str = wks.GetLongName();
		ASSERT(str == "");
		//but wks name can be set, which is Short Name
		wks.SetName("GoodName");
		out_str(wks.GetName());
	*/
	BOOL		SetLongName(LPCSTR lpcszLongName);
	
	/**#?
		It retrieves the comments from an object that supports Comments
	Paramaters:
		None
	Returns:
		The comments
	Remarks:
		Only Column and Page objects support comments
	Example:
		string str;
		Page pg = Project.Pages();
		if(pg)
			str = pg.GetComments();
		out_str(str);
	*/
	string		GetComments();
	
	/**#?
		It sets the comments with a text string to an object that supports Comments
	Parameters:
		lpcszLongName=pointer to the comments to set
	Returns:
		TRUE if OK, FALSE if object does not support comments.
	Remarks:
		Only Column and Page objects support comments
	Example:
		string str;
		str = "This is a test of some comments\r\nWhich can have multiple lines";
		Page pg = Project.Pages();
		if(pg)
			pg.SetComments(str);// use Rename dialog to see the result
		
	*/
	BOOL		SetComments(LPCSTR lpcszComments);

	
#endif	//_OC_VER > 0x0800

#if _OC_VER > 0x0703
	/**
		Example:
			void Run_GetStorage()
			{
				Tree	tr;
				storage st;
				vector<string> vsName;	
				Page pg = Project.Pages();
				
				pg.GetStorageNames(vsName);
				
				st = pg.GetStorage("system");
				tr = st;
				out_tree(tr);
			}
	*/	
	storage		GetStorage(LPCSTR lpcszName, bool bAdd = FALSE);
	
	/**
		SeeAlso:
			GetStorage			
	*/	
	BOOL 		GetStorageNames(vector<string> &vsNames);

	
	/**
	Copy object format into Clipboard. Format from clipboard maybe saved to theme file. 
	Parameters:
		dwPropertiesFilter	= filter for properties. See FILTERPROPERTYBITS enumeration in OC_const.h for bits description
		dwObjFilter			= filter for objects. See FILTEROBJECTBITS enumeration in OC_const.h for bits description
	SeeAlso:
		CopyThemeFromClipboard

	Example:
		void Run_CopyFormat()
		{
			Page pg = Project.Pages();
			pg.CopyFormat();
		}
	*/	
	BOOL		CopyFormat(DWORD dwPropertiesFilter = FPB_ALL, DWORD dwObjFilter = FOB_ALL);

	/**
	Apply format stored in theme file to object
	Parameters:
		lpcszXMLPath = path of XML theme file
		bRepaint	 = if TRUE object will be repainted when format is applied
	
	Example:
		void Run_ApplyFormat()
		{
			Page pg = Project.Pages();
			pg.ApplyFormat("themes\\Ticks All In.OTH");
		}
	*/
	BOOL		ApplyFormat(LPCSTR lpcszXMLPath, BOOL bRepaint = TRUE);
	
	/**
	Get object format into Tree
	Parameters:
		dwPropertiesFilter	= filter for properties. See FILTERPROPERTYBITS enumeration in OC_const.h for bits description
		dwObjFilter			= filter for objects. See FILTEROBJECTBITS enumeration in OC_const.h for bits description
	Example:
	void Run_GetApplyFormat()
	{
		Page pg1 = Project.Pages(1);
		Page pg2 = Project.Pages(2);
		Tree tr;
		tr = pg1.GetFormat();
		pg2.ApplyFormat(tr);
	}
	*/
	Tree		GetFormat(DWORD dwPropertiesFilter = FPB_ALL, DWORD dwObjFilter = FOB_ALL);
	
	/**
	Apply format stored in tree to object
	Parameters:
		trNode		 = contains format information
		bRepaint	 = if TRUE object will be repainted when format is applied
	Example:
	void Run_GetApplyFormat()
	{
		Page pg1 = Project.Pages(1);
		Page pg2 = Project.Pages(2);
		Tree tr;
		tr = pg1.GetFormat();
		pg2.ApplyFormat(tr);
	}
	*/
	BOOL		ApplyFormat(const TreeNode& trNode, BOOL bRepaint = TRUE);

	/**
		get named binary storage into vector of bytes
	Paramteres
		lpcszName = storage name, must be valid C identifier
		vb = vector of bytes to be retrieved
	Example:
		test_read()
		{
			Page pg = Project.Pages();
			if(!pg)
				return;
			
			vector<byte> vb;
			if(pg.GetMemory("Test", vb))
			{
				string strContents;
				if(strContents.SetBytes(vb))
					strContents.Write(WRITE_COMPILER_OUTPUT);
			}
		}
	Return:
		TRUE if success FALSE if name storage does not exist
	*/
	BOOL GetMemory(LPCSTR lpcszName, vector<byte>& vb);
	/**
		set/create named binary storage
	Paramteres
		lpcszName = storage name, must be valid C identifier
		vb = vector of bytes to be saved
	Example:
		string get_file(LPCSTR lpcszFilename)
		{
			string str;
			stdioFile ff;
			bool bRet = ff.Open(lpcszFilename, file::modeRead);
			if(!bRet)
			{
				out_str("file not found!");
				return str;
			}
			
			string strTemp;
			while(ff.ReadString(strTemp))
				str += strTemp + "\r\n";
			
			ff.Close();
			
			return str;
		}
		test_save()
		{
			Page pg = Project.Pages();
			if(!pg)
				return;
			
			string strFilename = GetAppPath() + "origin.ini";
			string strFileContent = get_file(strFilename);
			
			vector<byte> vb;
			if(strFileContent.GetBytes(vb) && pg.SetMemory("Test", vb))
				out_str("Saving origin.ini into page.info done");
		}
	Return:
		TRUE if success
	*/
	BOOL SetMemory(LPCSTR lpcszName, vector<byte>& vb);

	/**
		Show/Hide property of any Origin object
	Example:
		Worksheet wks = Project.ActiveLayer();
        if (wks)
        {
		wks.Columns(1).Show = 0;//hide column 2
		if(wks.Columns(1).Show == 0)
			out_str("Col(B) is hidden successfully");
        }
	*/
	BOOL		Show;

	/**
		The short name of the Origin object, which can be a Column, a Layer, or a Page
	Parameters: 
	Return:
		Name of the Origin object, or the Short Name if object has both long and short names.
	Example:
		Page page = Project.Pages();
		if(page)
			printf("The active window's short name is %s\n", page.GetName());
	*/	
	string		GetName();
	
	/**
	Provides internal unique identification number of Origin object
	Paramteres:
		bCreate = create ID if it was not created yet
	Return:
		0 if ID for object was not created. Object unique ID otherwise
	Example:
		void Run_GetUID()
		{
			Page pg = Project.Pages();
			UINT uID = pg.GetUID(TRUE);
			printf("%u",uID);	
		}
	*/
	UINT		GetUID(BOOL bCreate = FALSE);
#endif //#if _OC_VER > 0x0703


};

#endif // _ORGOBJ_H



