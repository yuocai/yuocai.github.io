/*------------------------------------------------------------------------------*
 * File Name: spcdata.h															*
 * Creation: SY 05-09-2003														*
 * Purpose: Origin C header	for SPC data class									*
 * Copyright (c) OriginLab Corp.2003											*
 * All Rights Reserved															*
 *------------------------------------------------------------------------------*/

/**
	This header file is used for exporting SPC. The following example show you how to export SPC file. 

	// Assume you have the data in worksheet.
	// If the corner object information in place, you can use the function like rtest() to export SPC.
	
	#include <spcdata.h>
	void rtest()
	{
		Worksheet wks = Project.ActiveLayer();
		if(wks)
		{
			// Must specify the corner object in which column, 
			// actually the corner object always in the first Y column.
			SPCData myData(wks, 0);	// The corner object in the first column(which index is 0).
			ASSERT( myData.IsValid() );
			
			myData.SaveAsSPC("D:\\test.spc");
		}
	}


	// Assume you have the data in worksheet.
	// If the corner object information is not in place, you need to write a function like wtest()
	// to create the corner object information and then export SPC.

	#include <spcdata.h>
	void wtest()
	{
		// Put the data into worksheet
		Worksheet wks = Project.ActiveLayer();
		if(wks)
		{
			// Must specify the corner object in which column, 
			// actually the corner object always in the first Y column.
			SPCData myData(wks,0);       // The corner object in the first column(which index is 0).
			ASSERT( myData.IsValid() );
			
			// Fill in the SPC additional information
			// Set text log
			string strLog = "Tester = OriginLab";
			myData.SetSPCTextLog(strLog);
			
			// MUST provide SPC main header and subfile header information
			OSPCMAINHEADER mySPCmainHd = {0};
			OSPCSUBHEADER mySPCsubHd = {0};
			
			mySPCmainHd.ftflgs = 0; // MUST set the correct SPC file type, 
									// spcFileTypeEven = 0, spcFileTypeXYY = 1, spcFileTypeXYXY = 2
			mySPCmainHd.ffirst = 1;
			mySPCmainHd.flast = 30;
			mySPCmainHd.fnsub =1;
			mySPCmainHd.fnpts = 30;
			myData.SetSPCMainHeader(&mySPCmainHd);
			
			// Must specify the subfile in which column using the column's name.
			mySPCsubHd.colname[0] = 'A';
			myData.SetSPCSubHeader(&mySPCsubHd, 1);	// subfile index from 1
			
			mySPCsubHd.colname[0] = 'B';
			myData.SetSPCSubHeader(&mySPCsubHd, 2);
			
			mySPCsubHd.colname[0] = 'C';
			myData.SetSPCSubHeader(&mySPCsubHd, 3);
			
			mySPCsubHd.colname[0] = 'D';
			myData.SetSPCSubHeader(&mySPCsubHd, 4);
			
			myData.SaveAsSPC("D:\\test.spc");
	   }
	}
*/

class SPCData
{
public:

	SPCData(Worksheet &wks, int nCol);

	BOOL IsValid();

	int SaveAsSPC(LPCSTR lpcszFileName);

	int SetSPCMainHeader(OSPCMAINHeader *lpSPCMainHeader);

	int GetSPCMainHeader(OSPCMAINHeader *lpSPCMainHeader);

	int SetSPCSubHeader(OSPCSUBHeader *lpSPCSubHeader, int nIndex);

	int GetSPCSubHeader(OSPCSUBHeader *lpSPCSubHeader, int nIndex);

	int GetSPCTextLog(string &strLog);

	int SetSPCTextLog(string strLog);

	int GetSPCBinLog(_VARIANT &varBin);

	int SetSPCBinLog(_VARIANT varBin);
};

