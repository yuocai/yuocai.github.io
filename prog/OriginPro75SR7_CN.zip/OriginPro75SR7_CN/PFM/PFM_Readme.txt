To install the Peak Fitting Module (PFM)
1. Open Origin
2. Drag the file PFM.opk onto the Origin application background image.

This will automatically install the PFM. A new PFM toolbar button will appear.