//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by SendNumericDataToWks.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_SENDNUMERICDATATOWKS_DIALOG 102
#define IDR_MAINFRAME                   128
#define IDC_ALWAYS_CREATE_NEW           1000
#define IDC_CONNECT_EXISTING_FIRST      1001
#define IDC_SHOW_ORIGIN_WINDOW          1002
#define IDC_EXIT_ORIGIN_ON_DISCONNECT   1003
#define IDC_CONNECT_ORIGIN              1004
#define IDC_DISCONNECT_ORIGIN           1005
#define IDC_WKS_NAME                    1006
#define IDC_WKS_COLUMNS                 1007
#define IDC_WKS_ROWS                    1008
#define IDC_APPEND_DATA                 1009
#define IDC_SEND_DATA                   1010
#define IDC_CLEAR_WORKSHEET             1011
#define IDC_SAVE_AS_FILE_NAME           1012
#define IDC_SAVE_PROJECT_ON_EXIT        1013

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        129
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1014
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
