
#include <windows.h>

/*
DllMain is an optional method of entry into a dynamic-link library (DLL).
If the function is used, it is called by the system when processes and threads
are initialized and terminated, or upon calls to the LoadLibrary and
FreeLibrary functions.
*/
BOOL APIENTRY DllMain(HANDLE hModule, DWORD ul_reason_for_call, LPVOID lpReserved)
{
	switch( ul_reason_for_call )
	{
	case DLL_PROCESS_ATTACH:
	case DLL_THREAD_ATTACH:
	case DLL_THREAD_DETACH:
	case DLL_PROCESS_DETACH:
		break;
	}
	return TRUE;
}


__declspec(dllexport) int IncrementMatrix(double *pdMatrix, int iRows, int iCols, double dIncAmount)
{
	int iRow, iCol;

	for( iRow = 0; iRow < iRows; iRow++ )
	{
		for( iCol = 0; iCol < iCols; iCol++ )
		{
			*pdMatrix += dIncAmount;
			pdMatrix++;
		}
	}

	return 0;
}
