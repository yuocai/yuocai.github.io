/*------------------------------------------------------------------------------*
 * File Name: GlobalFunctionsEx.c												*
 * Creation: GJL 8/11/03														*
 * Purpose: OriginC Source C file containing GlobalFunctions example.			*
 * Copyright (c) OriginLab Corp.		2003, 2004, 2005, 2006, 2007, 2008		*
 * All Rights Reserved															*
 *------------------------------------------------------------------------------*/
 
#include <Origin.h>

void CallGlobalFuncsEx()
{
	Dataset dsDataIn("Data1_A");

	BasicStats bsStat;

	BOOL bErr = Data_sum( &dsDataIn, &bsStat);

	printf("Min = %f\nMax = %f\nMean = %f\nSD = %f",
		bsStat.min, bsStat.max, bsStat.mean, bsStat.sd);
}
