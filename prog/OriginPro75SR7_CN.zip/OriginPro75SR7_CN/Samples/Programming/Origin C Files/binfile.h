/*------------------------------------------------------------------------------*
 * File Name: binfile.h															*
 * Creation: CPY 1/26/2002														*
 * Purpose: Binary File Import/Export Example for Origin C						*
 * Copyright (c) OriginLab Corp.	2002										*
 * All Rights Reserved															*
 * 																				*
 * Modification Log:															*
 *------------------------------------------------------------------------------*/

 
#ifndef _BINFILE_H
#define _BINFILE_H

#define MY_TEXT_SIZE	100

typedef struct tagMyMainHeader
{
	char	szTitle[MY_TEXT_SIZE];
	short	nColumns;
	float	factor; // calibration constant 
}MyMainHeader; 


BOOL myImport(string strFileName, string strWksName = ""); 
BOOL myExport(string strFileName, string strWksName = "");

#endif //_BINFILE_H
