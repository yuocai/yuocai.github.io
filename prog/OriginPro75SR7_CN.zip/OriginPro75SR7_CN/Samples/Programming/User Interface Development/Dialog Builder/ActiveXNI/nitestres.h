//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by C:\C\Vc32\OriginC\Samples\Dialogs\ActiveXNI\ResDLL\NiTest.rc
//
#define IDD_DIALOG1                     104
#define IDD_NICHART                     104
#define IDD_NI_GRAPH3D                  104
#define IDD_NI_CHART_RT                 105
#define IDD_SIMPLEUI_DIALOG             106
#define IDD_COLORMAPSTYLES_DIALOG       107
#define IDD_REGIONOFINTEREST_DIALOG     108
#define IDD_CORRELATE_DIALOG            109
#define IDC_CWGRAPH3D1                  6000
#define IDC_EDIT1                       6001
#define IDC_BUTTON1                     6002
#define IDC_CWSLIDE1                    6003
#define IDC_CWKNOB1                     6004
#define IDC_CWGRAPH1                    6005
#define IDC_CWKNOB_PEAK                 6006
#define IDC_CWSLIDE_UPDATE_FREQ         6007
#define IDC_CWSLIDE_OFFSET              6008
#define IDC_CWKNOB_NOISE                6009
#define IDC_KNOB                        6010
#define IDC_SLIDER                      6011
#define IDC_CWKNOB_PERCENT              6011
#define IDC_NUMERIC1                    6012
#define IDC_GRAPH                       6020
#define IDC_PLOT_DUAL_SINE_SURFACE      6022
#define IDC_PLOT_TORUS                  6023
#define IDC_MAP_AUTO_SCALE              6025
#define IDC_MAP_INTERPOLATE             6026
#define IDC_MAP_LOG                     6027
#define IDC_STYLE_NONE                  6028
#define IDC_STYLE_SHADED                6029
#define IDC_STYLE_COLOR_SPECTRUM        6030
#define IDC_STYLE_GRAY_SCALE            6031
#define IDC_STYLE_CUSTOM                6032
#define IDC_NUMERIC2                    6033
#define IDC_GRAPH_SURFACE               6033
#define IDC_CUSTOM_COLOR_INDICATOR1     6038
#define IDC_CUSTOM_COLOR_INDICATOR2     6039
#define IDC_CUSTOM_COLOR_INDICATOR3     6043
#define IDC_CUSTOM_COLOR_INDICATOR4     6044
#define IDC_CUSTOM_COLOR_INDICATOR5     6045
#define IDC_CUSTOM_COLOR1               6046
#define IDC_CUSTOM_COLOR2               6047
#define IDC_CUSTOM_COLOR3               6048
#define IDC_CUSTOM_COLOR4               6049
#define IDC_CUSTOM_COLOR5               6050
#define IDC_CUSTOM_MAP_VALUES           6052
#define IDC_CWGRAPH3D                   6060
#define IDC_CWGRAPHROI                  6061
#define IDC_RADIO_ROI                   6062
#define IDC_RADIO_ZPR                   6063
#define IDC_SIG2_NOISE_TEXT             6070
#define IDC_SIG1_GRAPH                  6071
#define IDC_SIG1_NOISE_TEXT             6072
#define IDC_SIG2_GRAPH                  6073
#define IDC_SIG1_POINTS                 6076
#define IDC_CORRELATION_GRAPH           6077
#define IDC_SIG2_POINTS                 6078
#define IDC_SIG1_CYCLES                 6081
#define IDC_SIG1_PHASE                  6082
#define IDC_SIG1_NOISE_TOGGLE           6083
#define IDC_SIG1_NOISE_AMP              6084
#define IDC_SIG1_WAVETYPE               6085
#define IDC_SIG2_CYCLES                 6086
#define IDC_SIG2_PHASE                  6087
#define IDC_SIG2_NOISE_TOGGLE           6088
#define IDC_SIG2_NOISE_AMP              6089
#define IDC_SIG2_WAVETYPE               6090
#define IDC_AUTO_GEN_CHECK              6091
#define IDC_GENERATE                    6092
#define IDC_QUIT                        6093
#define IDC_HELPBUTTON                  6094
#define IDD_DIALOG2                     7004
#define IDC_LIST1                       6011
#define IDC_CHECK1                      6012


// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        7005
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         6011
#define _APS_NEXT_SYMED_VALUE           8000
#endif
#endif
