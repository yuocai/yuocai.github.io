//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by D:\Program Files\OriginLab\OriginPro75\Samples\Programming\User Interface Development\Dialog Builder\ComboBox\ResDLL\ComboBox.rc
//
#define IDD_CB_COMBOBOX                 100
#define IDC_CB_COMBO1                   6000
#define IDC_CB_WINTEXT                  6001
#define IDC_CB_ACTIVATECHECK            6002

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        100
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         6003
#define _APS_NEXT_SYMED_VALUE           21000
#endif
#endif
