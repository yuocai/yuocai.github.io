//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by H:\Program Files\OriginLab\OriginPro8\OriginC\Samples\Dialogs\Edit\ResDLL\Edit.rc
//
#define IDD_EDIT                        100
#define IDC_RICHEDIT1                   6000
#define IDC_CHECK1                      6001
#define IDC_EDIT1                       6002
#define IDC_BUTTON1                     6003

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        101
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         6011
#define _APS_NEXT_SYMED_VALUE           21000
#endif
#endif
