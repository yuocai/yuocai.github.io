/*------------------------------------------------------------------------------*
 * File Name: ListDataSets.cpp				 									*
 * Creation: GJL 11/17/03 														*
 * Purpose: OriginC Source C file containing ListDataSets example dialog.		*
 * Copyright (c) OriginLab Corp.	2003, 2004, 2005, 2006, 2007		 		*
 * All Rights Reserved															*
 * 																				*
 * Modification Log:															*
 *------------------------------------------------------------------------------*/
 
#include <Origin.h>
#include <Dialog.h>
#include "ListDataSetsRes.h" // Resource DLL header
#include "ListDataSets.h" // Dialog class header

bool LaunchListDataSets() 
{
	ListDataSets dlgListDataSets;
	dlgListDataSets.DoModal(GetWindow());
	return true;
}





