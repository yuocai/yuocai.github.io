/*------------------------------------------------------------------------------*
 * File Name: Radio Buttons.cpp				 									*
 * Creation: GJL 11/19/03 														*
 * Purpose: OriginC Source C file containing Radio Buttons example dialog.		*
 * Copyright (c) OriginLab Corp.	2003, 2004, 2005, 2006, 2007		 		*
 * All Rights Reserved															*
 * 																				*
 * Modification Log:															*
 *------------------------------------------------------------------------------*/
 
#include <Origin.h>
#include <Dialog.h>
#include "Radio ButtonsRes.h" // Resource DLL header
#include "Radio Buttons.h" // Dialog class header

// Launch Dialog
bool LaunchRadioButtons() 
{
	RadioButtons dlgRadioButtons; // Declare Dialog object
	dlgRadioButtons.DoModal(GetWindow()); // Launch Dialog
	return true;
}





