//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by D:\OriginPro75SR1\Samples\Programming\User Interface Development\Dialog Builder\Wizard\ResDLL\wizard.rc
//

#define IDD_WIZARD                      100
#define IDC_PAGE_PLACEHOLDER            2000
#define IDD_FIRSTPAGE                   3000
#define IDD_SECONDPAGE                  3001
#define IDD_THIRDPAGE                   3002
#define IDC_CHECK1                      6000
#define IDC_BUTTON1                     6001
#define IDC_EDIT1                       6002
#define IDC_COMBO1                      6003
#define IDC_BUTTON2                     6004
#define IDC_BUTTON3                     6005

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        101
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         6006
#define _APS_NEXT_SYMED_VALUE           21000
#endif
#endif
