/*------------------------------------------------------------------------------*
 * File Name: WksControl.c	 													*
 * Creation: SDB 11/19/2003														*
 * Purpose: OriginC Source C file												*
 * Copyright (c) ABCD Corp.	2003, 2004, 2005, 2006, 2007, 2008, 2009, 2010		*
 * All Rights Reserved															*
 * 																				*
 * Modification Log:															*
 *------------------------------------------------------------------------------*/
 
#include <Origin.h>
#include <Dialog.h>
#include "WksControlRes.h" // resource DLL header
#include "WksControl.h" // dialog class header

//////// ////////////////////////////////////////////////////////////////////////////
// Start your functions here.

static WksControl myDlg;

bool LaunchWksControl() 
{
	myDlg.Create( GetWindow() );
	return true;
}





