/*------------------------------------------------------------------------------*
 * File Name: FileDialog.c														*
 * Creation: GJL, 7/14/2003														*
 * Purpose: OriginC Source C file for file dialog example.						*
 * Copyright (c) OriginLab Corp.			2003, 2004, 2005, 2006, 2007		*
 * All Rights Reserved															*
 *------------------------------------------------------------------------------*/
 
#include <origin.h>

void FileDialogEx()
{
	string strPath;
	StringArray saFiletypes;
	saFiletypes.SetSize(3);
	saFiletypes[0]="[Project (*.OPJ)] *.OPJ";
	saFiletypes[1]="[Old version (*.ORG)] *.ORG";
	saFiletypes[2]="[Worksheets (*.OGW)] *.OGW";

	strPath = GetOpenBox(saFiletypes, "C:\\Program Files\\", "Untitled", "OpenOPJ");

	if( !Project.Open(strPath) )
		printf("The file chosen %s is not a valid Origin file.\n", strPath);
}